The following files were generated for 'vio2' in directory
/home/omshripc/Sem 5/EE2003/ISE/expt2/exp2/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * vio2.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * vio2.cdc
   * vio2.ngc
   * vio2.v
   * vio2.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * vio2.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * vio2.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * vio2.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * vio2_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * vio2.gise
   * vio2.xise

Deliver Readme:
   Readme file for the IP.

   * vio2_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * vio2_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

