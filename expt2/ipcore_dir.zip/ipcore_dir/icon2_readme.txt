The following files were generated for 'icon2' in directory
/home/omshripc/Sem 5/EE2003/ISE/expt2/exp2/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * icon2.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * icon2.ngc
   * icon2.v
   * icon2.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * icon2.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * icon2.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * icon2.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * icon2_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * icon2.gise
   * icon2.xise

Deliver Readme:
   Readme file for the IP.

   * icon2_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * icon2_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

